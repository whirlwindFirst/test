package cn.yx;

import java.util.Vector;

public class ClientList {

    private final Vector<ClientInfo> ClientInfo = new Vector<ClientInfo>();

    private ClientList(){

    }

    private static final ClientList instance = new ClientList();

    public static ClientList getClientListInstance(){
        return instance;
    }

    public void addSocket(ClientInfo so){
        ClientInfo.add(so);
    }

    public void removeSocket(ClientInfo so){
        ClientInfo.remove(so);
    }

    public Vector<ClientInfo> getVector() {
        return ClientInfo;
    }


}
