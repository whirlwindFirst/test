package cn.yx;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Fuwuqi {
    public static void main(String[] args) throws IOException {
        //创建服务器对象
        ServerSocket ss = new ServerSocket(8888);
        System.out.println("服务器启动成功");
        //使用accept方法获取客户端对象
        while (true){
            Socket sk = ss.accept();
            System.out.println("有客户端连接服务器！");
            //将连接放进集合
            ClientList clientListInstance = ClientList.getClientListInstance();
            ClientInfo client = new ClientInfo();
            client.setSocket(sk);
            clientListInstance.addSocket(client);
            //JOptionPane.showMessageDialog(null, "有客户端连接到了本机的8888端口");

            new Thread(new Client(client)).start();
        }


       /* while(true){

            //用客服端对象获取字节输入流对象
            InputStream is = sk.getInputStream();
            //读取客户端发来的信息
            byte[] by = new byte[1024];
            int len = is.read(by);
            System.out.println(new String(by,0,len));
            //用客服端对象获取字节输出流对象
            OutputStream os = sk.getOutputStream();
            //使用字节输出流像客服端回复消息
            os.write("你也好啊".getBytes());
            //sk.close();
        }*/

    }
}
