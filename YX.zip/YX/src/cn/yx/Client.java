package cn.yx;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;

public class Client implements Runnable {

    private ClientInfo sc;

    public Client(ClientInfo sc){
        this.sc = sc;
    }

    @Override
    public void run() {

        while(true){

            try {
                //用客服端对象获取字节输入流对象
                InputStream is = sc.getSocket().getInputStream();
                //读取客户端发来的信息
                byte[] by = new byte[1024];
                int len = is.read(by);
                String s = new String(by, 0, len);

                OutputStream os = sc.getSocket().getOutputStream();
                //用客服端对象获取字节输出流对象
                //System.out.println("传送结果为：" + new String(s.getBytes(),"gbk"));
                System.out.println("传送结果为：" + s);
                String ClientName = s.split("：")[0];
                sc.setName(ClientName);
                String ClientMessage = s.split("：")[1];
                String[] tos = ClientMessage.split("to");
                String to = "";
                if(tos.length >1){
                    ClientMessage = tos[0];
                     to = tos[1];
                }
                System.out.println("客户端：" + ClientName + "发来消息");
                System.out.println(s);
                //获取集合中的所有连接
                ClientList clientListInstance = ClientList.getClientListInstance();

                //判断是群发还是私发
                if(tos.length > 1){
                    for (ClientInfo clientInfo : clientListInstance.getVector()) {
                        if(!sc.equals(clientInfo) && clientInfo.getName().equals(to)){
                            System.out.println(ClientName + "给" + to + "发送消息！");
                            clientInfo.getSocket().getOutputStream().write((ClientName + "给您私发消息：" + ClientMessage).getBytes());
                        }
                    }
                }else{
                    for (ClientInfo clientInfo : clientListInstance.getVector()) {
                        if(!sc.equals(clientInfo)){
                            if("down".equals(ClientMessage)){
                                System.out.println(ClientName + "下线了1");
                                clientInfo.getSocket().getOutputStream().write(("系统：" + ClientName + "下线了").getBytes());
                            }else{
                                System.out.println(ClientName + "群消息发送！");
                                clientInfo.getSocket().getOutputStream().write(by);
                            }

                        }
                    }
                }

                if("down".equals(ClientMessage)){

                    //使用字节输出流像客服端回复消息
                    os.write("down".getBytes());
                    //将集合中的此连接删除
                    clientListInstance.removeSocket(sc);
                System.out.println("正在和" + ClientName + "断开连接...");
                sc.getSocket().close();
                System.out.println("和" + ClientName + "断开连接成功！");
                return;
            }
            //使用字节输出流像客服端回复消息
            os.write("系统：您的消息发送成功！".getBytes());

            }catch (SocketException e){
                e.printStackTrace();
                System.out.println(sc.getName() + "断开连接！");

                return;
            }catch (IOException e){
                e.printStackTrace();
            }

        }


    }
}
